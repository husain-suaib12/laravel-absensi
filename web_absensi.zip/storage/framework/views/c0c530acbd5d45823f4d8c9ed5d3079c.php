<?php $__env->startSection('main'); ?>
    <?php if (isset($component)) { $__componentOriginalca4e451880e8e4c0adb1ece844b9b173 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalca4e451880e8e4c0adb1ece844b9b173 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.running-text','data' => ['text' => '📌 Master Jabatan — Kelola data jabatan sebagai dasar sistem','color' => 'rt-master']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('running-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['text' => '📌 Master Jabatan — Kelola data jabatan sebagai dasar sistem','color' => 'rt-master']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalca4e451880e8e4c0adb1ece844b9b173)): ?>
<?php $attributes = $__attributesOriginalca4e451880e8e4c0adb1ece844b9b173; ?>
<?php unset($__attributesOriginalca4e451880e8e4c0adb1ece844b9b173); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalca4e451880e8e4c0adb1ece844b9b173)): ?>
<?php $component = $__componentOriginalca4e451880e8e4c0adb1ece844b9b173; ?>
<?php unset($__componentOriginalca4e451880e8e4c0adb1ece844b9b173); ?>
<?php endif; ?>

    <h3>Master Jabatan</h3>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    <a href="<?php echo e(route('jabatan.create')); ?>" class="btn btn-primary mb-2">Tambah Jabatan</a>

    <table class="table table-bordered">
        <tr>
            <th>No</th>
            <th>Nama Jabatan</th>
            <th>Aksi</th>
        </tr>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($i + 1); ?></td>
                <td><?php echo e($d->nama_jabatan); ?></td>
                <td>
                    <a href="<?php echo e(route('jabatan.edit', $d->id_jabatan)); ?>" class="btn btn-sm btn-warning">Edit</a>
                    <form action="<?php echo e(route('jabatan.destroy', $d->id_jabatan)); ?>" method="POST" class="d-inline">
                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-sm btn-danger" onclick="return confirm('Hapus data?')">Hapus</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ThinkPad\Documents\tugas_akhir\web\web_absensi\resources\views/jabatan/index.blade.php ENDPATH**/ ?>