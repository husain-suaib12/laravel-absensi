<?php if(!empty($text)): ?>
    <div class="running-wrapper <?php echo e($color ?? 'rt-primary'); ?> mb-4">
        <div class="running-text">
            <?php echo $text; ?>

        </div>
    </div>
<?php endif; ?>
<?php /**PATH C:\Users\ThinkPad\Documents\tugas_akhir\web\web_absensi\resources\views\components\running-text.blade.php ENDPATH**/ ?>