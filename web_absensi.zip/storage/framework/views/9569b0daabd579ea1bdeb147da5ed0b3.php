<?php $__env->startSection('title', 'Data Pegawai'); ?>

<?php $__env->startSection('main'); ?>
    <?php if (isset($component)) { $__componentOriginalca4e451880e8e4c0adb1ece844b9b173 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalca4e451880e8e4c0adb1ece844b9b173 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.running-text','data' => ['text' => '👥 Manajemen Data Pegawai — Kelola data pegawai secara terstruktur dan aman','color' => 'rt-manajemen']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('running-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['text' => '👥 Manajemen Data Pegawai — Kelola data pegawai secara terstruktur dan aman','color' => 'rt-manajemen']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalca4e451880e8e4c0adb1ece844b9b173)): ?>
<?php $attributes = $__attributesOriginalca4e451880e8e4c0adb1ece844b9b173; ?>
<?php unset($__attributesOriginalca4e451880e8e4c0adb1ece844b9b173); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalca4e451880e8e4c0adb1ece844b9b173)): ?>
<?php $component = $__componentOriginalca4e451880e8e4c0adb1ece844b9b173; ?>
<?php unset($__componentOriginalca4e451880e8e4c0adb1ece844b9b173); ?>
<?php endif; ?>

    <div class="page-heading">
        <h3>Data Pegawai</h3>
    </div>

    <div class="page-content">
        <section class="row">
            <div class="col-12 col-lg-12">
                <div class="card">

                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h4 class="card-title mb-0">Daftar Pegawai</h4>
                        <a href="/pegawai/create" class="btn btn-primary btn-sm">
                            <i class="bi bi-plus-circle"></i> Tambah Pegawai
                        </a>
                    </div>

                    <div class="card-body">

                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Foto</th>
                                        <th>NIK</th>
                                        <th>Nama</th>
                                        <th>Jabatan</th>
                                        <th>Pendidikan</th>
                                        <th>Status</th>
                                        <th>No HP</th>
                                        <th>Gaji Pokok</th> 
                                        <th>Aksi</th>
                                    </tr>
                                </thead>

                                <tbody>
                                    <?php $__currentLoopData = $pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>

                                            <td>
                                                <?php if($p->foto): ?>
                                                    <img src="<?php echo e(asset('foto/' . $p->foto)); ?>"
                                                        alt="Foto <?php echo e($p->nama); ?>" width="50" height="50"
                                                        class="rounded">
                                                <?php else: ?>
                                                    <span>Tidak ada foto</span>
                                                <?php endif; ?>
                                            </td>


                                            <td><?php echo e($p->nik); ?></td>
                                            <td><?php echo e($p->nama); ?></td>
                                            <td><?php echo e($p->nama_jabatan); ?></td>
                                            <td><?php echo e($p->tingkat); ?></td>

                                            <td>
                                                <?php if($p->status_aktif == '1'): ?>
                                                    <span class="badge bg-success">Pegawai</span>
                                                <?php else: ?>
                                                    <span class="badge bg-info">Honorer</span>
                                                <?php endif; ?>
                                            </td>


                                            <td><?php echo e($p->no_hp); ?></td>

                                            
                                            <td>
                                                Rp <?php echo e(number_format($p->gaji_pokok, 0, ',', '.')); ?>

                                            </td>

                                            <td>
                                                <a href="<?php echo e(route('pegawai.edit', $p->id_pegawai)); ?>"
                                                    class="btn btn-warning btn-sm">
                                                    <i class="bi bi-pencil-fill"></i>
                                                </a>

                                                <form action="<?php echo e(route('pegawai.destroy', $p->id_pegawai)); ?>"
                                                    method="POST" style="display:inline;">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-danger btn-sm"
                                                        onclick="return confirm('Hapus data ini?')">
                                                        <i class="bi bi-trash"></i>
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>

                            </table>
                        </div>

                    </div>

                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ThinkPad\Documents\tugas_akhir\web\web_absensi\resources\views\pegawai\index.blade.php ENDPATH**/ ?>