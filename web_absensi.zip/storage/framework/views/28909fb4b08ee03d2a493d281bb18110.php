<?php $__env->startSection('title', 'Edit Jam Kerja'); ?>
<?php $__env->startSection('main'); ?>
    <div class="page-heading">
        <h3>Edit Jam Kerja</h3>
    </div>

    <div class="page-content">
        <div class="card">
            <div class="card-body">

                <form action="<?php echo e(route('jam-kerja.update', $jamKerja->id_jam)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <div class="mb-3">
                        <label>Jam Masuk Mulai</label>
                        <input type="time" name="jam_masuk_mulai" class="form-control"
                            value="<?php echo e(\Carbon\Carbon::createFromFormat('H:i:s', $jamKerja->jam_masuk_mulai)->format('H:i')); ?>"
                            required>
                    </div>

                    <div class="mb-3">
                        <label>Jam Masuk Selesai</label>
                        <input type="time" name="jam_masuk_selesai" class="form-control"
                            value="<?php echo e(\Carbon\Carbon::createFromFormat('H:i:s', $jamKerja->jam_masuk_selesai)->format('H:i')); ?>"
                            required>
                    </div>

                    <div class="mb-3">
                        <label>Jam Pulang Mulai</label>
                        <input type="time" name="jam_pulang_mulai" class="form-control"
                            value="<?php echo e(\Carbon\Carbon::createFromFormat('H:i:s', $jamKerja->jam_pulang_mulai)->format('H:i')); ?>"
                            required>
                    </div>

                    <div class="mb-3">
                        <label>Jam Pulang Selesai</label>
                        <input type="time" name="jam_pulang_selesai" class="form-control"
                            value="<?php echo e(\Carbon\Carbon::createFromFormat('H:i:s', $jamKerja->jam_pulang_selesai)->format('H:i')); ?>"
                            required>
                    </div>

                    <button class="btn btn-success">Simpan</button>
                    <a href="<?php echo e(route('jam-kerja.index')); ?>" class="btn btn-secondary">Kembali</a>
                </form>


            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ThinkPad\Documents\tugas_akhir\web\web_absensi\resources\views/jam_kerja/edit.blade.php ENDPATH**/ ?>