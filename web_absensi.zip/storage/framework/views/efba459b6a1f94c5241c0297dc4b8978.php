<?php $__env->startSection('main'); ?>
    <div class="container mt-5">

        <div class="card shadow-lg border-0 rounded-4">
            <div class="card-header bg-primary text-white rounded-top-4">
                <h4 class="mb-0">✏️ Edit User</h4>
            </div>

            <div class="card-body p-4">

                <form action="<?php echo e(route('user.update', $user->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <div class="row">

                        
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-semibold">Email</label>
                            <input type="email" name="email" class="form-control rounded-3"
                                value="<?php echo e(old('email', $user->email)); ?>" required>
                        </div>

                        
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-semibold">Role</label>
                            <select name="role" class="form-control rounded-3">
                                <option value="admin" <?php echo e($user->role == 'admin' ? 'selected' : ''); ?>>
                                    Admin
                                </option>
                                <option value="pegawai" <?php echo e($user->role == 'pegawai' ? 'selected' : ''); ?>>
                                    Pegawai
                                </option>
                            </select>
                        </div>

                        
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-semibold">
                                Password Baru
                                <small class="text-muted">(kosongkan jika tidak diganti)</small>
                            </label>
                            <input type="password" name="password" class="form-control rounded-3">
                        </div>

                    </div>

                    
                    <div class="d-flex justify-content-between mt-4">

                        <a href="<?php echo e(route('user.index')); ?>" class="btn btn-secondary px-4 rounded-3">
                            ⬅ Kembali
                        </a>

                        <button type="submit" class="btn btn-success px-4 rounded-3 shadow-sm">
                            💾 Update User
                        </button>

                    </div>

                </form>

            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ThinkPad\Documents\tugas_akhir\web\web_absensi\resources\views/user/edit.blade.php ENDPATH**/ ?>