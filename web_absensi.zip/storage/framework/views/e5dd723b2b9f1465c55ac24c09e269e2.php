<?php $__env->startSection('title', 'Master Lokasi Absen'); ?>

<?php $__env->startSection('main'); ?>

    <?php if (isset($component)) { $__componentOriginalca4e451880e8e4c0adb1ece844b9b173 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalca4e451880e8e4c0adb1ece844b9b173 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.running-text','data' => ['text' => '📌 Master Lokasi Absen — Kelola lokasi absensi kantor','color' => 'rt-master']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('running-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['text' => '📌 Master Lokasi Absen — Kelola lokasi absensi kantor','color' => 'rt-master']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalca4e451880e8e4c0adb1ece844b9b173)): ?>
<?php $attributes = $__attributesOriginalca4e451880e8e4c0adb1ece844b9b173; ?>
<?php unset($__attributesOriginalca4e451880e8e4c0adb1ece844b9b173); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalca4e451880e8e4c0adb1ece844b9b173)): ?>
<?php $component = $__componentOriginalca4e451880e8e4c0adb1ece844b9b173; ?>
<?php unset($__componentOriginalca4e451880e8e4c0adb1ece844b9b173); ?>
<?php endif; ?>

    <div class="main-content">
        <section class="section">
            <div class="section-header">
                <h1>Master Lokasi Absen</h1>
            </div>

            <a href="<?php echo e(route('lokasi.create')); ?>" class="btn btn-primary mb-3">+ Tambah Lokasi</a>

            <div class="card">
                <div class="card-header">
                    <h4>Daftar Lokasi</h4>
                </div>

                <div class="card-body table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Nama Lokasi</th>
                                <th>Latitude</th>
                                <th>Longitude</th>
                                <th>Radius</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $lokasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($i + 1); ?></td>
                                    <td><?php echo e($x->nama_lokasi); ?></td>
                                    <td><?php echo e($x->latitude); ?></td>
                                    <td><?php echo e($x->longitude); ?></td>
                                    <td><?php echo e($x->radius_master); ?> m</td>
                                    <td>
                                        <a href="<?php echo e(route('lokasi.edit', $x->id_lokasi)); ?>"
                                            class="btn btn-warning btn-sm">Edit</a>

                                        <form action="<?php echo e(route('lokasi.destroy', $x->id_lokasi)); ?>" method="POST"
                                            style="display:inline-block;">
                                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                            <button onclick="return confirm('Yakin hapus?')"
                                                class="btn btn-danger btn-sm">Hapus</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ThinkPad\Documents\tugas_akhir\web\web_absensi\resources\views\lokasi\index.blade.php ENDPATH**/ ?>