<div id="sidebar" class="active">
    <div class="sidebar-wrapper active shadow-sm">

        
        <div class="sidebar-header d-flex align-items-center px-3 py-3 border-bottom">
            <img src="<?php echo e(asset('template/assets/compiled/svg/favicon.svg')); ?>" alt="" style="width:32px;">
            <div class="ms-2">
                <h5 class="mb-0 fw-bold">Absensi Desa</h5>

            </div>
        </div>

        
        <div class="sidebar-menu mt-2">
            <ul class="menu">

                <li class="sidebar-title text-uppercase">Menu Utama</li>

                
                <li class="sidebar-item <?php echo e(request()->routeIs('welcome') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('welcome')); ?>" class="sidebar-link">
                        <i class="bi bi-grid-fill"></i>
                        <span>Dashboard</span>
                    </a>
                </li>

                
                <li class="sidebar-item <?php echo e(request()->is('absensi*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('absensi.index')); ?>" class="sidebar-link">
                        <i class="bi bi-journal-check"></i>
                        <span>Data Absensi</span>
                    </a>
                </li>

                
                <li class="sidebar-item <?php echo e(request()->is('izin*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('izin.index')); ?>" class="sidebar-link">
                        <i class="bi bi-clipboard-check"></i>
                        <span>Validasi Izin</span>
                    </a>
                </li>

                
                <li class="sidebar-item <?php echo e(request()->is('gaji*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('gaji.index')); ?>" class="sidebar-link">
                        <i class="bi bi-cash-stack"></i>
                        <span>Rekap Gaji</span>
                    </a>
                </li>

                <li class="sidebar-title text-uppercase mt-3">Manajemen</li>

                
                <li
                    class="sidebar-item has-sub <?php echo e(request()->is('pegawai*') || request()->is('user*') ? 'active' : ''); ?>">
                    <a href="#" class="sidebar-link">
                        <i class="bi bi-collection-fill"></i>
                        <span>Manajemen</span>
                    </a>
                    <ul class="submenu">
                        <li class="submenu-item <?php echo e(request()->is('pegawai*') ? 'active' : ''); ?>">
                            <a href="/pegawai">
                                <i class="bi bi-people-fill"></i>
                                <span>Data Pegawai</span>
                            </a>
                        </li>
                        <li class="submenu-item <?php echo e(request()->is('user*') ? 'active' : ''); ?>">
                            <a href="/user">
                                <i class="bi bi-person-badge-fill"></i>
                                <span>Data User</span>
                            </a>
                        </li>
                    </ul>
                </li>

                <li class="sidebar-title text-uppercase mt-3">Master Data</li>

                
                <li class="sidebar-item has-sub <?php echo e(request()->is('lokasi*') ? 'active' : ''); ?>">
                    <a href="#" class="sidebar-link">
                        <i class="bi bi-grid-1x2-fill"></i>
                        <span>Master</span>
                    </a>
                    <ul class="submenu">
                        <li class="submenu-item <?php echo e(request()->is('lokasi*') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('lokasi.index')); ?>">
                                <i class="bi bi-geo-alt-fill"></i>
                                <span>Lokasi Kantor</span>
                            </a>
                        </li>
                        <li class="submenu-item <?php echo e(request()->is('jam-kerja*') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('jam-kerja.index')); ?>">
                                <i class="bi bi-clock-fill"></i>
                                <span>Jam Kerja</span>
                            </a>
                        </li>
                        <li class="submenu-item <?php echo e(request()->is('jabatan*') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('jabatan.index')); ?>">
                                <i class="bi bi-person-badge-fill"></i>
                                <span>Jabatan</span>
                            </a>
                        </li>
                        <li class="submenu-item <?php echo e(request()->is('pendidikan*') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('pendidikan.index')); ?>">
                                <i class="bi bi-mortarboard-fill"></i>
                                <span>Pendidikan</span>
                            </a>
                        </li>
                        <li class="submenu-item <?php echo e(request()->is('jenis-potongan*') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('jenis-potongan.index')); ?>">
                                <i class="bi bi-scissors"></i>
                                <span>Jenis Potongan</span>
                            </a>
                        </li>
                    </ul>
                </li>

                
                <li class="sidebar-item mt-4">
                    <form action="<?php echo e(route('logout')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="sidebar-link text-danger"
                            style="border:none;background:none;width:100%;text-align:left;">
                            <i class="bi bi-box-arrow-right"></i>
                            <span>Logout</span>
                        </button>
                    </form>
                </li>

            </ul>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\ThinkPad\Documents\tugas_akhir\web\web_absensi\resources\views\layout\sidebar.blade.php ENDPATH**/ ?>