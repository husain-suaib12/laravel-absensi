<?php $__env->startSection('title', 'Rekap Gaji Bulanan'); ?>

<?php $__env->startSection('main'); ?>
    <div class="page-content">

        <h3>Rekap Gaji Bulanan</h3>

        
        <form method="GET" class="row mb-3">
            <div class="col-md-3">
                <input type="month" name="bulan" class="form-control" value="<?php echo e($tahun); ?>-<?php echo e($bulan); ?>">
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn btn-primary">Tampilkan</button>
            </div>
        </form>

        
        <form action="<?php echo e(route('gaji.generate')); ?>" method="POST" class="mb-3">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="bulan" value="<?php echo e($bulan); ?>">
            <input type="hidden" name="tahun" value="<?php echo e($tahun); ?>">
            <button type="submit" class="btn btn-success" onclick="return confirm('Hitung ulang gaji bulan ini?')">
                Generate Gaji Bulanan
            </button>
        </form>

        
        <div class="card">
            <div class="card-body table-responsive">

                <table class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Pegawai</th>
                            <th>Hadir</th>
                            <th>Terlambat</th>
                            <th>Tanpa Keterangan</th>
                            <th>Gaji Pokok</th>
                            <th>Total Potongan</th>
                            <th>Gaji Bersih</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $rekap; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td>
                                    <?php echo e($r->nama); ?> <br>
                                    <small class="text-muted"><?php echo e($r->nik); ?></small>
                                </td>
                                <td><?php echo e($r->jumlah_hadir); ?></td>
                                <td><?php echo e($r->jumlah_terlambat); ?></td>
                                <td><?php echo e($r->jumlah_tanpa_keterangan); ?></td>
                                <td>Rp <?php echo e(number_format($r->gaji_pokok, 0, ',', '.')); ?></td>
                                <td class="text-danger">
                                    Rp <?php echo e(number_format($r->total_potongan, 0, ',', '.')); ?>

                                </td>
                                <td class="fw-bold text-success">
                                    Rp <?php echo e(number_format($r->gaji_bersih, 0, ',', '.')); ?>

                                </td>
                                <td>
                                    <a href="<?php echo e(route('gaji.detail', $r->id_pegawai)); ?>?bulan=<?php echo e($bulan); ?>&tahun=<?php echo e($tahun); ?>"
                                        class="btn btn-sm btn-primary">
                                        Detail
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="9" class="text-center text-muted">
                                    Belum ada data rekap
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>

            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ThinkPad\Documents\tugas_akhir\web\web_absensi\resources\views\gaji\rekap.blade.php ENDPATH**/ ?>