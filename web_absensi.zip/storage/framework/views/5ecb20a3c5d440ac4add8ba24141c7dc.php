<?php $__env->startSection('main'); ?>
    <h3><?php echo e(isset($pendidikan) ? 'Edit' : 'Tambah'); ?> Pendidikan</h3>

    <form method="POST"
        action="<?php echo e(isset($pendidikan) ? route('pendidikan.update', $pendidikan->id_pendidikan) : route('pendidikan.store')); ?>">
        <?php echo csrf_field(); ?>
        <?php if(isset($pendidikan)): ?>
            <?php echo method_field('PUT'); ?>
        <?php endif; ?>

        <div class="mb-3">
            <label>Tingkat Pendidikan</label>
            <input type="text" name="tingkat" class="form-control" value="<?php echo e($pendidikan->tingkat ?? ''); ?>" required>
        </div>

        <button class="btn btn-success">Simpan</button>
        <a href="<?php echo e(route('pendidikan.index')); ?>" class="btn btn-secondary">Kembali</a>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ThinkPad\Documents\tugas_akhir\web\web_absensi\resources\views\pendidikan\edit.blade.php ENDPATH**/ ?>