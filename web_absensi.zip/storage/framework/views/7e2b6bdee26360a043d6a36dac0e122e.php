<?php $__env->startSection('main'); ?>
    <h3><?php echo e(isset($potongan) ? 'Edit' : 'Tambah'); ?> Jenis Potongan</h3>

    <form method="POST"
        action="<?php echo e(isset($potongan) ? route('jenis-potongan.update', $potongan->id_jenis) : route('jenis-potongan.store')); ?>">

        <?php echo csrf_field(); ?>
        <?php if(isset($potongan)): ?>
            <?php echo method_field('PUT'); ?>
        <?php endif; ?>

        <div class="mb-3">
            <label>Nama Potongan</label>
            <input type="text" name="nama_potongan" class="form-control" value="<?php echo e($potongan->nama_potongan ?? ''); ?>"
                required>
        </div>

        <div class="mb-3">
            <label>Nilai</label>
            <input type="text" name="nilai" class="form-control" value="<?php echo e($potongan->nilai ?? ''); ?>">
            <small class="text-muted">contoh: 50000 atau 5%</small>
        </div>

        <button class="btn btn-success">Simpan</button>
        <a href="<?php echo e(route('jenis-potongan.index')); ?>" class="btn btn-secondary">Kembali</a>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ThinkPad\Documents\tugas_akhir\web\web_absensi\resources\views/jenis_potongan/form.blade.php ENDPATH**/ ?>