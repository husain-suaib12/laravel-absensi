<?php $__env->startSection('title', 'Data Absensi'); ?>

<?php $__env->startSection('main'); ?>
    <div class="container-fluid px-4">
        <?php if (isset($component)) { $__componentOriginalca4e451880e8e4c0adb1ece844b9b173 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalca4e451880e8e4c0adb1ece844b9b173 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.running-text','data' => ['text' => '📊 Data Absensi Pegawai — Pantau kehadiran pegawai secara akurat','color' => 'rt-success']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('running-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['text' => '📊 Data Absensi Pegawai — Pantau kehadiran pegawai secara akurat','color' => 'rt-success']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalca4e451880e8e4c0adb1ece844b9b173)): ?>
<?php $attributes = $__attributesOriginalca4e451880e8e4c0adb1ece844b9b173; ?>
<?php unset($__attributesOriginalca4e451880e8e4c0adb1ece844b9b173); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalca4e451880e8e4c0adb1ece844b9b173)): ?>
<?php $component = $__componentOriginalca4e451880e8e4c0adb1ece844b9b173; ?>
<?php unset($__componentOriginalca4e451880e8e4c0adb1ece844b9b173); ?>
<?php endif; ?>

        
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h4 class="fw-bold mb-0">Data Absensi Pegawai</h4>
                <small class="text-muted">
                    Rekap absensi pegawai berdasarkan periode
                </small>
            </div>

            <a href="<?php echo e(route('absensi.cetak', ['bulan' => $bulan, 'tahun' => $tahun, 'q' => $q])); ?>" target="_blank"
                class="btn btn-danger shadow-sm">
                <i class="bi bi-file-earmark-pdf"></i> Cetak PDF
            </a>
        </div>

        
        <div class="card shadow-sm border-0 mb-4">
            <div class="card-body">
                <form class="row g-3" method="GET">
                    <div class="col-md-3">
                        <label class="form-label fw-semibold">Bulan</label>
                        <select name="bulan" class="form-select">
                            <?php for($i = 1; $i <= 12; $i++): ?>
                                <option value="<?php echo e(sprintf('%02d', $i)); ?>"
                                    <?php echo e($bulan == sprintf('%02d', $i) ? 'selected' : ''); ?>>
                                    <?php echo e(DateTime::createFromFormat('!m', $i)->format('F')); ?>

                                </option>
                            <?php endfor; ?>
                        </select>
                    </div>

                    <div class="col-md-3">
                        <label class="form-label fw-semibold">Tahun</label>
                        <select name="tahun" class="form-select">
                            <?php for($y = 2022; $y <= date('Y'); $y++): ?>
                                <option value="<?php echo e($y); ?>" <?php echo e($tahun == $y ? 'selected' : ''); ?>>
                                    <?php echo e($y); ?>

                                </option>
                            <?php endfor; ?>
                        </select>
                    </div>

                    <div class="col-md-4">
                        <label class="form-label fw-semibold">Cari Pegawai</label>
                        <input type="text" name="q" value="<?php echo e($q); ?>" class="form-control"
                            placeholder="Masukkan nama pegawai">
                    </div>

                    <div class="col-md-2 d-flex align-items-end">
                        <button class="btn btn-primary w-100">
                            <i class="bi bi-filter"></i> Filter
                        </button>
                    </div>
                </form>
            </div>
        </div>

        
        <div class="card shadow-sm border-0">
            <div class="card-header bg-white">
                <div class="fw-bold">
                    Rekap Absensi
                    <?php echo e(DateTime::createFromFormat('!m', $bulan)->format('F')); ?>

                    <?php echo e($tahun); ?>

                </div>
                <?php if($lokasi): ?>
                    <small class="text-muted">
                        Lokasi Kantor: <strong><?php echo e($lokasi->nama_lokasi); ?></strong>
                    </small>
                <?php endif; ?>
            </div>

            <div class="card-body p-0">

                <?php if($absensi->count() == 0): ?>
                    <div class="text-center text-muted py-5">
                        <i class="bi bi-calendar-x fs-1 mb-3 d-block"></i>
                        Belum ada data absensi untuk periode ini
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th class="ps-4">No</th>
                                    <th>Pegawai</th>
                                    <th>Tanggal</th>
                                    <th>Jam Masuk</th>
                                    <th>Jam Pulang</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $absensi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="ps-4">
                                            <?php echo e($absensi->firstItem() + $i); ?>

                                        </td>
                                        <td class="fw-semibold">
                                            <?php echo e($a->nama_pegawai); ?>

                                        </td>
                                        <td><?php echo e($a->tanggal); ?></td>
                                        <td><?php echo e($a->jam_masuk ?? '-'); ?></td>
                                        <td><?php echo e($a->jam_pulang ?? '-'); ?></td>
                                        <td>
                                            <?php if($a->status === 'hadir'): ?>
                                                <span class="badge rounded-pill bg-success px-3">Hadir</span>
                                            <?php elseif($a->status === 'izin'): ?>
                                                <span class="badge rounded-pill bg-warning text-dark px-3">Izin</span>
                                            <?php elseif($a->status === 'sakit'): ?>
                                                <span class="badge rounded-pill bg-info px-3">Sakit</span>
                                            <?php elseif($a->status === 'alpa'): ?>
                                                <span class="badge rounded-pill bg-danger px-3">Alpa</span>
                                            <?php elseif($a->status === 'dinas_luar'): ?>
                                                <span class="badge rounded-pill bg-primary px-3">
                                                    <i class="bi bi-briefcase-fill me-1"></i> Dinas Luar
                                                </span>
                                            <?php else: ?>
                                                <span class="badge rounded-pill bg-secondary px-3">-</span>
                                            <?php endif; ?>
                                        </td>

                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

                    <div class="p-3">
                        <?php echo e($absensi->links()); ?>

                    </div>
                <?php endif; ?>

            </div>
        </div>

    </div>

    
    <style>
        .table-hover tbody tr:hover {
            background-color: #838f9b;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ThinkPad\Documents\tugas_akhir\web\web_absensi\resources\views/absensi/index.blade.php ENDPATH**/ ?>