<?php $__env->startSection('main'); ?>
    <?php if (isset($component)) { $__componentOriginalca4e451880e8e4c0adb1ece844b9b173 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalca4e451880e8e4c0adb1ece844b9b173 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.running-text','data' => ['text' => '👋 Selamat Datang di Sistem Absensi Pegawai Desa — Kelola data secara terintegrasi','color' => 'rt-primary']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('running-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['text' => '👋 Selamat Datang di Sistem Absensi Pegawai Desa — Kelola data secara terintegrasi','color' => 'rt-primary']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalca4e451880e8e4c0adb1ece844b9b173)): ?>
<?php $attributes = $__attributesOriginalca4e451880e8e4c0adb1ece844b9b173; ?>
<?php unset($__attributesOriginalca4e451880e8e4c0adb1ece844b9b173); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalca4e451880e8e4c0adb1ece844b9b173)): ?>
<?php $component = $__componentOriginalca4e451880e8e4c0adb1ece844b9b173; ?>
<?php unset($__componentOriginalca4e451880e8e4c0adb1ece844b9b173); ?>
<?php endif; ?>

    <div class="container-fluid px-4">

        
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h4 class="fw-bold mb-0">Dashboard</h4>
                <small class="text-muted">
                    Sistem Informasi Absensi Pegawai Desa
                </small>
            </div>
            <span class="badge bg-light text-dark px-3 py-2">
                <?php echo e(now()->format('d M Y')); ?>

            </span>
        </div>

        
        <div class="row g-4 mb-4">

            
            <div class="col-md-3">
                <div class="card shadow-sm border-0 h-100 card-hover">
                    <div class="card-body d-flex justify-content-between align-items-center">
                        <div>
                            <small class="text-muted">Hadir Hari Ini</small>
                            <h3 class="fw-bold mb-0"><?php echo e($hadir); ?></h3>
                        </div>
                        <div class="icon bg-success text-white rounded-circle p-3">
                            <i class="bi bi-check-circle-fill fs-4"></i>
                        </div>
                    </div>
                </div>
            </div>

            
            <div class="col-md-3">
                <div class="card shadow-sm border-0 h-100 card-hover">
                    <div class="card-body d-flex justify-content-between align-items-center">
                        <div>
                            <small class="text-muted">Dinas Luar</small>
                            <h3 class="fw-bold mb-0"><?php echo e($dinas); ?></h3>
                        </div>
                        <div class="icon bg-primary text-white rounded-circle p-3">
                            <i class="bi bi-briefcase-fill fs-4"></i>
                        </div>
                    </div>
                </div>
            </div>

            
            <div class="col-md-3">
                <div class="card shadow-sm border-0 h-100 card-hover">
                    <div class="card-body d-flex justify-content-between align-items-center">
                        <div>
                            <small class="text-muted">Alpa</small>
                            <h3 class="fw-bold mb-0"><?php echo e($alpa); ?></h3>
                        </div>
                        <div class="icon bg-danger text-white rounded-circle p-3">
                            <i class="bi bi-x-circle-fill fs-4"></i>
                        </div>
                    </div>
                </div>
            </div>

            
            <div class="col-md-3">
                <div class="card shadow-sm border-0 h-100 card-hover">
                    <div class="card-body d-flex justify-content-between align-items-center">
                        <div>
                            <small class="text-muted">Izin / Sakit</small>
                            <h3 class="fw-bold mb-0"><?php echo e($izin); ?></h3>
                        </div>
                        <div class="icon bg-warning text-white rounded-circle p-3">
                            <i class="bi bi-exclamation-circle-fill fs-4"></i>
                        </div>
                    </div>
                </div>
            </div>

            
            <div class="col-md-12">
                <div class="card shadow-sm border-0 card-hover">
                    <div class="card-body d-flex justify-content-between align-items-center">
                        <div>
                            <small class="text-muted">Total Pegawai Terdaftar</small>
                            <h3 class="fw-bold mb-0"><?php echo e($totalPegawai); ?></h3>
                        </div>
                        <div class="icon bg-secondary text-white rounded-circle p-3">
                            <i class="bi bi-people-fill fs-4"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        
        <div class="card shadow-sm border-0">
            <div class="card-header bg-white fw-bold">
                Absensi Terbaru
            </div>
            <div class="card-body p-0">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th class="ps-4">Nama Pegawai</th>
                            <th>Tanggal</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $absensiTerbaru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="ps-4"><?php echo e($a->nama); ?></td>
                                <td><?php echo e(\Carbon\Carbon::parse($a->tanggal)->format('d M Y')); ?></td>
                                <td>
                                    <?php if($a->id_jenis == 4): ?>
                                        <span class="badge rounded-pill bg-success px-3">Hadir</span>
                                    <?php elseif($a->id_jenis == 1): ?>
                                        <span class="badge rounded-pill bg-danger px-3">Alpa</span>
                                    <?php elseif($a->id_jenis == 2): ?>
                                        <span class="badge rounded-pill bg-warning text-dark px-3">Sakit</span>
                                    <?php elseif($a->id_jenis == 3): ?>
                                        <span class="badge rounded-pill bg-info px-3">Izin</span>
                                    <?php elseif($a->id_jenis == 5): ?>
                                        <span class="badge rounded-pill bg-primary px-3">Dinas Luar</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="3" class="text-center py-4 text-muted">
                                    Belum ada data absensi
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>

    
    <style>
        .card-hover {
            transition: all .2s ease-in-out;
        }

        .card-hover:hover {
            transform: translateY(-4px);
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ThinkPad\Documents\tugas_akhir\web\web_absensi\resources\views\welcome.blade.php ENDPATH**/ ?>