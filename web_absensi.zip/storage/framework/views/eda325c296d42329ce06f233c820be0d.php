<?php $__env->startSection('main'); ?>
    <div class="container">
        <h4 class="mb-3">Edit Lokasi Kantor</h4>

        <form action="<?php echo e(route('lokasi.update', $lokasi->id_lokasi)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="form-group">
                <label>Nama Lokasi</label>
                <input type="text" name="nama_lokasi" class="form-control" value="<?php echo e($lokasi->nama_lokasi); ?>" required>
            </div>

            <div class="form-group">
                <label>Latitude</label>
                <input type="text" name="latitude" class="form-control" value="<?php echo e($lokasi->latitude); ?>" required>
            </div>

            <div class="form-group">
                <label>Longitude</label>
                <input type="text" name="longitude" class="form-control" value="<?php echo e($lokasi->longitude); ?>" required>
            </div>

            <div class="form-group">
                <label>Radius (meter)</label>
                <input type="number" name="radius" class="form-control" value="<?php echo e($lokasi->radius_master); ?>" required>
            </div>

            <button type="submit" class="btn btn-primary">Update</button>
        </form>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ThinkPad\Documents\tugas_akhir\web\web_absensi\resources\views\lokasi\edit.blade.php ENDPATH**/ ?>