<?php $__env->startSection('main'); ?>
    <?php if (isset($component)) { $__componentOriginalca4e451880e8e4c0adb1ece844b9b173 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalca4e451880e8e4c0adb1ece844b9b173 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.running-text','data' => ['text' => '📝 Master Jenis Potongan — Atur jenis Potongan pegawai yang tersedia','color' => 'rt-master']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('running-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['text' => '📝 Master Jenis Potongan — Atur jenis Potongan pegawai yang tersedia','color' => 'rt-master']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalca4e451880e8e4c0adb1ece844b9b173)): ?>
<?php $attributes = $__attributesOriginalca4e451880e8e4c0adb1ece844b9b173; ?>
<?php unset($__attributesOriginalca4e451880e8e4c0adb1ece844b9b173); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalca4e451880e8e4c0adb1ece844b9b173)): ?>
<?php $component = $__componentOriginalca4e451880e8e4c0adb1ece844b9b173; ?>
<?php unset($__componentOriginalca4e451880e8e4c0adb1ece844b9b173); ?>
<?php endif; ?>

    <h3>Jenis Potongan</h3>

    <a href="<?php echo e(route('jenis-potongan.create')); ?>" class="btn btn-primary mb-3">
        + Tambah Jenis Potongan
    </a>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Potongan</th>
                <th>Nilai</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($i + 1); ?></td>
                    <td><?php echo e($row->nama_potongan); ?></td>
                    <td><?php echo e($row->nilai); ?></td>
                    <td>
                        <a href="<?php echo e(route('jenis-potongan.edit', $row->id_jenis)); ?>" class="btn btn-warning btn-sm">Edit</a>

                        <form action="<?php echo e(route('jenis-potongan.destroy', $row->id_jenis)); ?>" method="POST"
                            style="display:inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-danger btn-sm" onclick="return confirm('Hapus data?')">
                                Hapus
                            </button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ThinkPad\Documents\tugas_akhir\web\web_absensi\resources\views/jenis_potongan/index.blade.php ENDPATH**/ ?>