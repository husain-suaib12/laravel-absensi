<?php $__env->startSection('main'); ?>
    <div class="page-heading">
        <h3>Tambah User</h3>
    </div>

    <div class="page-content">
        <div class="card">
            <div class="card-body">
                <form action="/user" method="POST">
                    <?php echo csrf_field(); ?>

                    <div class="mb-3">
                        <label>Pegawai</label>
                        <select name="id_pegawai" class="form-control" required>
                            <option value="">-- Pilih Pegawai --</option>
                            <?php $__currentLoopData = $pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($p->id_pegawai); ?>"><?php echo e($p->nama); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label>Email</label>
                        <input type="email" name="email" class="form-control" required>
                    </div>

                    <div class="mb-3">
                        <label>Password</label>
                        <input type="password" name="password" class="form-control" required>
                    </div>

                    <button class="btn btn-success">Simpan</button>
                    <a href="/user" class="btn btn-secondary">Kembali</a>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ThinkPad\Documents\tugas_akhir\web\web_absensi\resources\views/user/create.blade.php ENDPATH**/ ?>