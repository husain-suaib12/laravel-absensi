<?php $__env->startSection('main'); ?>
    <?php if (isset($component)) { $__componentOriginalca4e451880e8e4c0adb1ece844b9b173 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalca4e451880e8e4c0adb1ece844b9b173 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.running-text','data' => ['text' => '💰 Rekap Gaji Bulanan — Perhitungan gaji otomatis & transparan','color' => 'rt-purple']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('running-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['text' => '💰 Rekap Gaji Bulanan — Perhitungan gaji otomatis & transparan','color' => 'rt-purple']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalca4e451880e8e4c0adb1ece844b9b173)): ?>
<?php $attributes = $__attributesOriginalca4e451880e8e4c0adb1ece844b9b173; ?>
<?php unset($__attributesOriginalca4e451880e8e4c0adb1ece844b9b173); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalca4e451880e8e4c0adb1ece844b9b173)): ?>
<?php $component = $__componentOriginalca4e451880e8e4c0adb1ece844b9b173; ?>
<?php unset($__componentOriginalca4e451880e8e4c0adb1ece844b9b173); ?>
<?php endif; ?>

    
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h4 class="fw-bold mb-0">Rekap Gaji Bulanan</h4>
            <small class="text-muted">
                Perhitungan gaji pegawai berdasarkan absensi
            </small>
        </div>
    </div>

    
    <div class="card shadow-sm border-0 mb-4">
        <div class="card-body">
            <form method="GET" class="row g-2 align-items-end">
                <div class="col-md-2">
                    <label class="form-label">Bulan</label>
                    <select name="bulan" class="form-select">
                        <?php for($i = 1; $i <= 12; $i++): ?>
                            <option value="<?php echo e(sprintf('%02d', $i)); ?>" <?php echo e($bulan == sprintf('%02d', $i) ? 'selected' : ''); ?>>
                                <?php echo e($i); ?>

                            </option>
                        <?php endfor; ?>
                    </select>
                </div>

                <div class="col-md-2">
                    <label class="form-label">Tahun</label>
                    <select name="tahun" class="form-select">
                        <?php for($i = date('Y'); $i >= date('Y') - 5; $i--): ?>
                            <option value="<?php echo e($i); ?>" <?php echo e($tahun == $i ? 'selected' : ''); ?>>
                                <?php echo e($i); ?>

                            </option>
                        <?php endfor; ?>
                    </select>
                </div>

                <div class="col-md-5">
                    <button class="btn btn-primary me-1">
                        <i class="bi bi-search"></i> Tampilkan
                    </button>

                    <button type="button" class="btn btn-success" id="btnGenerate">
                        <i class="bi bi-calculator"></i> Generate Gaji
                    </button>
                </div>
            </form>
        </div>
    </div>

    
    <div id="alertContainer"></div>

    
    <div class="card shadow-sm border-0">
        <div class="card-header bg-white fw-bold">
            Daftar Rekap Gaji
        </div>

        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th class="ps-4">No</th>
                            <th>Nama Pegawai</th>
                            <th>NIK</th>
                            <th>Gaji Pokok</th>
                            <th>Hari Dipotong</th>
                            <th>Total Potongan</th>
                            <th>Gaji Bersih</th>
                            <th>Status</th>
                            <th class="text-center">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $rekap; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="<?php echo e($r->jumlah_tanpa_keterangan > 3 ? 'table-danger' : ''); ?>">
                                <td class="ps-4"><?php echo e($loop->iteration); ?></td>
                                <td class="fw-semibold"><?php echo e($r->nama); ?></td>
                                <td><?php echo e($r->nik); ?></td>
                                <td>Rp <?php echo e(number_format($r->gaji_pokok, 0, ',', '.')); ?></td>
                                <td class="text-center"><?php echo e($r->jumlah_tanpa_keterangan); ?></td>
                                <td class="text-danger fw-semibold">
                                    Rp <?php echo e(number_format($r->total_potongan, 0, ',', '.')); ?>

                                </td>
                                <td class="text-success fw-bold">
                                    Rp <?php echo e(number_format($r->gaji_bersih, 0, ',', '.')); ?>

                                </td>
                                <td>
                                    <?php if($r->is_locked): ?>
                                        <span class="badge rounded-pill bg-success px-3">Locked</span>
                                    <?php else: ?>
                                        <span class="badge rounded-pill bg-warning text-dark px-3">Draft</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center">
                                    <a href="<?php echo e(route('gaji.detail', $r->id_pegawai)); ?>?bulan=<?php echo e($bulan); ?>&tahun=<?php echo e($tahun); ?>"
                                        class="btn btn-info btn-sm">
                                        <i class="bi bi-eye"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="9" class="text-center text-muted py-4">
                                    <i class="bi bi-folder-x fs-3 d-block mb-2"></i>
                                    Data gaji belum digenerate
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    
    <script>
        document.getElementById('btnGenerate').addEventListener('click', function() {
            if (!confirm('Generate gaji bulan ini?')) return;

            const bulan = document.querySelector('select[name="bulan"]').value;
            const tahun = document.querySelector('select[name="tahun"]').value;

            fetch(`/gaji/generate?bulan=${bulan}&tahun=${tahun}`)
                .then(async res => {
                    const data = await res.json();
                    if (!res.ok) throw new Error(data.message || 'Server Error');
                    return data;
                })
                .then(data => {
                    alert(data.message);
                    location.reload();
                })
                .catch(err => {
                    // INI PENTING: Menampilkan detail error yang sebenarnya dari Laravel
                    alert("DETAIL ERROR: " + err.message);
                    console.error(err);
                });
        });
    </script>

    <style>
        .table-hover tbody tr:hover {
            background-color: #f8f9fa;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ThinkPad\Documents\tugas_akhir\web\web_absensi\resources\views\gaji\index.blade.php ENDPATH**/ ?>