<?php $__env->startSection('main'); ?>
    <div class="container">

        <h4 class="mb-3">Detail Gaji Pegawai</h4>

        
        <div class="card mb-3">
            <div class="card-body">
                <table class="table table-sm">
                    <tr>
                        <th width="200">Nama</th>
                        <td><?php echo e($pegawai->nama); ?></td>
                    </tr>
                    <tr>
                        <th>NIK</th>
                        <td><?php echo e($pegawai->nik); ?></td>
                    </tr>
                    <tr>
                        <th>Gaji Pokok</th>
                        <td>Rp <?php echo e(number_format($pegawai->gaji_pokok, 0, ',', '.')); ?></td>
                    </tr>
                    <tr>
                        <th>Bulan</th>
                        <td><?php echo e($bulan); ?> / <?php echo e($tahun); ?></td>
                    </tr>
                </table>
            </div>
        </div>

        
        <div class="card mb-3">
            <div class="card-header bg-light">
                <strong>Rekap Potongan</strong>
            </div>
            <div class="card-body">
                <?php if($rekap): ?>
                    <table class="table table-bordered">
                        <tr>
                            <th>Jumlah Hari Potong</th>
                            <td><?php echo e($rekap->jumlah_tanpa_keterangan); ?> hari</td>
                        </tr>
                        <tr>
                            <th>Total Potongan</th>
                            <td class="text-danger fw-semibold">
                                Rp <?php echo e(number_format($rekap->total_potongan, 0, ',', '.')); ?>

                                (<?php echo e(round(($rekap->total_potongan / $pegawai->gaji_pokok) * 100, 2)); ?>%)
                            </td>
                        </tr>
                        <tr>
                            <th>Gaji Bersih</th>
                            <td class="text-success">
                                Rp <?php echo e(number_format($rekap->gaji_bersih, 0, ',', '.')); ?>

                            </td>
                        </tr>
                    </table>
                <?php else: ?>
                    <div class="alert alert-warning">
                        Gaji bulan ini belum digenerate
                    </div>
                <?php endif; ?>
            </div>
        </div>

        
        <div class="card">
            <div class="card-header bg-light">
                <strong>Riwayat Kehadiran & Izin</strong>
            </div>
            <div class="card-body">

                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Tanggal</th>
                            <th>Status</th>
                            <th>Keterangan</th>
                            <th>Potong Gaji</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $absensi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="<?php echo e($a->id_jenis == 1 ? 'table-danger' : ''); ?>">
                                <td><?php echo e($a->tanggal); ?></td>
                                <td>
                                    
                                    <span
                                        class="badge <?php echo e($a->id_jenis == 1 ? 'bg-danger' : ($a->id_jenis == 4 ? 'bg-success' : 'bg-warning text-dark')); ?>">
                                        <?php echo e($a->nama_potongan); ?> 
                                    </span>
                                </td>
                                <td><?php echo e($a->keterangan ?? '-'); ?></td>
                                <td class="<?php echo e($a->id_jenis == 1 ? 'text-danger fw-bold' : 'text-success'); ?>">
                                    <?php echo e($a->id_jenis == 1 ? 'Ya' : 'Tidak'); ?>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        
                        <?php
                            $izinDitolak = DB::table('izin_pegawai')
                                ->where('id_pegawai', $pegawai->id_pegawai)
                                ->where('status_izin', 'ditolak')
                                ->whereMonth('tanggal', $bulan)
                                ->whereYear('tanggal', $tahun)
                                ->get();
                        ?>

                        <?php $__currentLoopData = $izinDitolak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="table-danger">
                                <td><?php echo e($i->tanggal); ?></td>
                                <td>Izin Ditolak</td>
                                <td><?php echo e($i->jenis); ?></td>
                                <td class="text-danger">Ya</td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        
                        <?php
                            $izinDisetujui = DB::table('izin_pegawai')
                                ->where('id_pegawai', $pegawai->id_pegawai)
                                ->where('status_izin', 'disetujui')
                                ->whereMonth('tanggal', $bulan)
                                ->whereYear('tanggal', $tahun)
                                ->get();
                        ?>

                        <?php $__currentLoopData = $izinDisetujui; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="table-success">
                                <td><?php echo e($i->tanggal); ?></td>
                                <td>Izin Disetujui</td>
                                <td><?php echo e($i->jenis); ?></td>
                                <td class="text-success">Tidak</td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ThinkPad\Documents\tugas_akhir\web\web_absensi\resources\views/gaji/detail.blade.php ENDPATH**/ ?>