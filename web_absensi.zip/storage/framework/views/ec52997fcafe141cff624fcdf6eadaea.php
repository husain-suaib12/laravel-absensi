<?php $__env->startSection('title', 'Edit Pegawai'); ?>

<?php $__env->startSection('main'); ?>
    <div class="page-heading">
        <h3>Edit Data Pegawai</h3>
    </div>

    <div class="page-content">
        <section class="row">
            <div class="col-12 col-lg-8">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Form Edit Pegawai</h4>
                    </div>

                    <div class="card-body">
                        <form action="<?php echo e(route('pegawai.update', $pegawai->id_pegawai)); ?>" method="POST"
                            enctype="multipart/form-data">

                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>



                            <div class="col-md-6 mb-3">
                                <label>NIK</label>
                                <input type="text" name="nik" class="form-control" value="<?php echo e($pegawai->nik); ?>"
                                    required>
                            </div>

                            <div class="col-md-6 mb-3">
                                <label>Nama</label>
                                <input type="text" name="nama" class="form-control" value="<?php echo e($pegawai->nama); ?>"
                                    required>
                            </div>

                            <div class="col-md-6 mb-3">
                                <label>Jabatan</label>
                                <select name="id_jabatan" class="form-control">
                                    <?php $__currentLoopData = $jabatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($j->id_jabatan); ?>"
                                            <?php echo e($j->id_jabatan == $pegawai->id_jabatan ? 'selected' : ''); ?>>
                                            <?php echo e($j->nama_jabatan); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="col-md-6 mb-3">
                                <label>Pendidikan</label>
                                <select name="id_pendidikan" class="form-control">
                                    <?php $__currentLoopData = $pendidikan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($p->id_pendidikan); ?>"
                                            <?php echo e($p->id_pendidikan == $pegawai->id_pendidikan ? 'selected' : ''); ?>>
                                            <?php echo e($p->tingkat); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="col-md-6 mb-3">
                                <label>Status</label>
                                <select name="status_aktif" class="form-control">
                                    <option value="1" <?php echo e($pegawai->status_aktif == 1 ? 'selected' : ''); ?>>Pegawai
                                    </option>
                                    <option value="0" <?php echo e($pegawai->status_aktif == 0 ? 'selected' : ''); ?>>Honorer
                                    </option>
                                </select>
                            </div>



                            <div class="col-md-6 mb-3">
                                <label>No HP</label>
                                <input type="text" name="no_hp" class="form-control" value="<?php echo e($pegawai->no_hp); ?>"
                                    required>
                            </div>

                            <div class="col-md-6 mb-3">
                                <label>Alamat</label>
                                <textarea name="alamat" class="form-control" required><?php echo e($pegawai->alamat); ?></textarea>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label>Gaji Pokok</label>
                                <input type="number" name="gaji_pokok" class="form-control"
                                    value="<?php echo e($pegawai->gaji_pokok); ?>" required>
                            </div>


                            <div class="col-md-6 mb-3">
                                <label>Foto</label><br>
                                <?php if($pegawai->foto): ?>
                                    <img src="<?php echo e(asset('foto/' . $pegawai->foto)); ?>" width="80" class="mb-2">
                                <?php endif; ?>
                                <input type="file" name="foto" class="form-control">
                            </div>

                            <button type="submit" class="btn btn-primary">Update</button>
                            <a href="<?php echo e(route('pegawai.index')); ?>" class="btn btn-secondary">Kembali</a>

                        </form>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ThinkPad\Documents\tugas_akhir\web\web_absensi\resources\views\pegawai\edit.blade.php ENDPATH**/ ?>