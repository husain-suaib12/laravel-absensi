<?php $__env->startSection('title', 'Detail Jam Kerja'); ?>
<?php $__env->startSection('main'); ?>
    <?php if (isset($component)) { $__componentOriginalca4e451880e8e4c0adb1ece844b9b173 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalca4e451880e8e4c0adb1ece844b9b173 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.running-text','data' => ['text' => '⏰ Master Jam Kerja — Atur jam kerja pegawai','color' => 'rt-master']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('running-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['text' => '⏰ Master Jam Kerja — Atur jam kerja pegawai','color' => 'rt-master']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalca4e451880e8e4c0adb1ece844b9b173)): ?>
<?php $attributes = $__attributesOriginalca4e451880e8e4c0adb1ece844b9b173; ?>
<?php unset($__attributesOriginalca4e451880e8e4c0adb1ece844b9b173); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalca4e451880e8e4c0adb1ece844b9b173)): ?>
<?php $component = $__componentOriginalca4e451880e8e4c0adb1ece844b9b173; ?>
<?php unset($__componentOriginalca4e451880e8e4c0adb1ece844b9b173); ?>
<?php endif; ?>

    <div class="page-heading">
        <h3>Jam Kerja</h3>
    </div>

    <div class="page-content">
        <div class="card">
            <div class="card-body">

                <?php if(session('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>

                <?php if($jamKerja): ?>
                    <table class="table table-bordered">
                        <tr>
                            <th>Jam Masuk</th>
                            <td>
                                <?php echo e(substr($jamKerja->jam_masuk_mulai, 0, 5)); ?>

                                -
                                <?php echo e(substr($jamKerja->jam_masuk_selesai, 0, 5)); ?>

                            </td>
                        </tr>
                        <tr>
                            <th>Jam Pulang</th>
                            <td>
                                <?php echo e(substr($jamKerja->jam_pulang_mulai, 0, 5)); ?>

                                -
                                <?php echo e(substr($jamKerja->jam_pulang_selesai, 0, 5)); ?>

                            </td>
                        </tr>
                    </table>

                    <a href="<?php echo e(route('jam-kerja.edit', $jamKerja->id_jam)); ?>" class="btn btn-primary">
                        Edit Jam Kerja
                    </a>
                <?php else: ?>
                    <div class="alert alert-warning">
                        Data jam kerja belum tersedia
                    </div>
                <?php endif; ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ThinkPad\Documents\tugas_akhir\web\web_absensi\resources\views/jam_kerja/index.blade.php ENDPATH**/ ?>