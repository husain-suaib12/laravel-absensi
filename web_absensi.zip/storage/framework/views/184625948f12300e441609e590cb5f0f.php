<?php $__env->startSection('title', 'Tambah Pegawai'); ?>

<?php $__env->startSection('main'); ?>
    <div class="page-heading">
        <h3>Tambah Pegawai</h3>
    </div>

    <div class="page-content">
        <section class="row">
            <div class="col-12 col-lg-8">
                <div class="card">
                    <div class="card-header">

                        <form action="<?php echo e(route('pegawai.store')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="row">

                                <div class="col-md-6 mb-3">
                                    <label>NIK</label>
                                    <input type="number" name="nik" class="form-control"required>
                                </div>

                                <div class="col-md-6 mb-3">
                                    <label>Nama Pegawai</label>
                                    <input type="text" name="nama" class="form-control" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label>No Hp</label>
                                    <input type="number" name="no_hp" class="form-control" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label>Alamat</label>
                                    <input type="text" name="alamat" class="form-control" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label>Jabatan</label>
                                    <select name="id_jabatan" class="form-control" required>
                                        <option value="">-- Pilih Jabatan --</option>
                                        <?php $__currentLoopData = $jabatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($j->id_jabatan); ?>"><?php echo e($j->nama_jabatan); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                <div class="col-md-6 mb-3">
                                    <label>Pendidikan</label>
                                    <select name="id_pendidikan" class="form-control" required>
                                        <option value="">-- Pilih Pendidikan --</option>
                                        <?php $__currentLoopData = $pendidikan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($p->id_pendidikan); ?>"><?php echo e($p->tingkat); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                <div class="col-md-6 mb-3">
                                    <label>Status Pegawai</label>
                                    <select name="status_aktif" class="form-control" required>
                                        <option value="">-- Pilih Status --</option>
                                        <option value="1">Pegawai</option>
                                        <option value="0">Honorer</option>
                                    </select>
                                </div>


                                <div class="col-md-6 mb-3">
                                    <label>Gaji Pokok</label>
                                    <input type="number" name="gaji_pokok" class="form-control" required
                                        placeholder="Masukkan gaji pokok">
                                </div>

                                <div class="col-md-6 mb-3">
                                    <label>Foto</label>
                                    <input type="file" name="foto" class="form-control" required>
                                </div>
                            </div>

                            <button type="submit" class="btn btn-primary">Simpan</button>

                        </form>

                    </div>
                </div>
        </section>


    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ThinkPad\Documents\tugas_akhir\web\web_absensi\resources\views\pegawai\create.blade.php ENDPATH**/ ?>