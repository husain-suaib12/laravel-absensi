<?php $__env->startSection('title', 'Izin Pegawai'); ?>

<?php $__env->startSection('main'); ?>
    <div class="container">

        <h4 class="mb-3">Input Izin / Sakit</h4>

        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
        <?php endif; ?>

        <form method="POST" action="<?php echo e(route('izin.store')); ?>" class="row mb-4">
            <?php echo csrf_field(); ?>

            <div class="col-md-3 mb-2">
                <select name="id_pegawai" class="form-control" required>
                    <option value="">-- Pilih Pegawai --</option>
                    <?php $__currentLoopData = $pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($p->id_pegawai); ?>"><?php echo e($p->nama); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="col-md-2 mb-2">
                <input type="date" name="tanggal" class="form-control" required>
            </div>

            <div class="col-md-2 mb-2">
                <select name="jenis" class="form-control" required>
                    <option value="Izin">Izin</option>
                    <option value="Sakit">Sakit</option>
                </select>
            </div>

            <div class="col-md-3 mb-2">
                <input type="text" name="keterangan" class="form-control" placeholder="Keterangan">
            </div>

            <div class="col-md-2 mb-2">
                <button class="btn btn-primary w-100">Simpan</button>
            </div>
        </form>

        <hr>

        <h5>Data Pengajuan Izin Pegawai</h5>

        <div class="table-responsive">
            <table class="table table-bordered table-striped">
                <thead class="table-light">
                    <tr>
                        <th>No</th>
                        <th>Nama Pegawai</th>
                        <th>Tanggal</th>
                        <th>Jenis Izin</th>
                        <th>Keterangan</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $izin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($i->nama); ?></td>
                            <td><?php echo e($i->tanggal); ?></td>
                            <td><?php echo e($i->jenis); ?></td>
                            <td><?php echo e($i->keterangan); ?></td>
                            <td>
                                <span
                                    class="badge
                                <?php echo e($i->status_izin == 'disetujui' ? 'bg-success' : ($i->status_izin == 'ditolak' ? 'bg-danger' : 'bg-warning')); ?>">
                                    <?php echo e(ucfirst($i->status_izin)); ?>

                                </span>
                            </td>
                            <td>
                                <?php if($i->status_izin == 'pending'): ?>
                                    <form action="<?php echo e(route('izin.validasi', $i->id_izin)); ?>" method="POST"
                                        class="d-flex gap-1">
                                        <?php echo csrf_field(); ?>
                                        <button name="status_izin" value="disetujui"
                                            class="btn btn-success btn-sm">Setujui</button>
                                        <button name="status_izin" value="ditolak"
                                            class="btn btn-danger btn-sm">Tolak</button>
                                    </form>
                                <?php else: ?>
                                    -
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7" class="text-center text-muted">Belum ada data pengajuan</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ThinkPad\Documents\tugas_akhir\web\web_absensi\resources\views\gaji\izin.blade.php ENDPATH**/ ?>