<!DOCTYPE html>
<html>

<head>
    <style>
        body {
            font-family: sans-serif;
            font-size: 12px;
        }

        .title {
            text-align: center;
            margin-bottom: 10px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }

        th,
        td {
            border: 1px solid #444;
            padding: 6px;
            text-align: center;
        }

        th {
            background: #e5e5e5;
        }
    </style>
</head>

<body>

    <h2 class="title">REKAP ABSENSI PEGAWAI</h2>
    <h4 class="title">
        Bulan: <?php echo e(DateTime::createFromFormat('!m', $bulan)->format('F')); ?> <?php echo e($tahun); ?>

    </h4>
    <h5 class="title">Lokasi Kantor: <?php echo e($lokasi->nama_lokasi); ?></h5>

    <table>
        <thead>
            <tr>
                <th>No</th>
                <th>Pegawai</th>
                <th>Tanggal</th>
                <th>Masuk</th>
                <th>Pulang</th>
                <th>Status</th>

            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $absensi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($i + 1); ?></td>
                    <td><?php echo e($a->nama_pegawai); ?></td>
                    <td><?php echo e($a->tanggal); ?></td>
                    <td><?php echo e($a->jam_masuk ?? '-'); ?></td>
                    <td><?php echo e($a->jam_pulang ?? '-'); ?></td>
                    <td><?php echo e($a->status); ?></td>

                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

</body>

</html>
<?php /**PATH C:\Users\ThinkPad\Documents\tugas_akhir\web\web_absensi\resources\views\absensi\pdf.blade.php ENDPATH**/ ?>