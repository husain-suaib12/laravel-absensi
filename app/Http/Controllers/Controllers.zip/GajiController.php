<?php

namespace App\Http\Controllers;

use App\Models\Absensi;
use App\Models\pegawai;
use App\Models\RekapGajiBulanan;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class GajiController extends Controller
{
    /**
     * =========================
     * INDEX REKAP GAJI
     * =========================
     */
    public function index(Request $request)
    {
        $bulan = $request->input('bulan', date('m'));
        $tahun = $request->input('tahun', date('Y'));
        $periode = $tahun.'-'.$bulan;

        // Ambil semua rekap gaji untuk bulan dan tahun
        $rekap = RekapGajiBulanan::join('pegawai', 'rekap_gaji_bulanan.id_pegawai', '=', 'pegawai.id_pegawai')
            ->select(
                'rekap_gaji_bulanan.*',
                'pegawai.nama',
                'pegawai.nik',
                'pegawai.gaji_pokok'
            )
            ->get();

        return view('gaji.index', compact('rekap', 'bulan', 'tahun'));
    }

    /**
     * =========================
     * GENERATE GAJI BULANAN
     * ATURAN:
     * - ALPA → POTONG
     * - IZIN DISETUJUI → TIDAK POTONG
     * - IZIN DITOLAK → SUDAH TERHITUNG SEBAGAI ALPA
     * =========================
     */
    public function generate(Request $request)
    {
        $bulan = $request->input('bulan', date('m'));
        $tahun = $request->input('tahun', date('Y'));
        $periode = $tahun.'-'.$bulan;

        $pegawaiList = Pegawai::all();

        foreach ($pegawaiList as $pegawai) {

            // Hitung absensi per jenis
            $hadir = $pegawai->absensi()
                ->whereYear('tanggal', $tahun)
                ->whereMonth('tanggal', $bulan)
                ->where('id_jenis', 4) // Hadir
                ->count();

            $izin = $pegawai->absensi()
                ->whereYear('tanggal', $tahun)
                ->whereMonth('tanggal', $bulan)
                ->where('id_jenis', 3) // Izin disetujui
                ->count();

            $sakit = $pegawai->absensi()
                ->whereYear('tanggal', $tahun)
                ->whereMonth('tanggal', $bulan)
                ->where('id_jenis', 2) // Sakit
                ->count();

            $alfa = $pegawai->absensi()
                ->whereYear('tanggal', $tahun)
                ->whereMonth('tanggal', $bulan)
                ->where('id_jenis', 1) // Alfa / izin ditolak
                ->count();

            // Hitung potongan per hari sebagai persentase dari gaji pokok
            $gaji_pokok = $pegawai->gaji_pokok ?? 0;

            // Misal: 1 hari potongan = 1/30 gaji pokok
            $potongan_per_hari = $gaji_pokok / 30;

            // Total potongan
            $total_potongan = $alfa * $potongan_per_hari;

            // Gaji bersih
            $gaji_bersih = $gaji_pokok - $total_potongan;

            // Simpan rekap
            RekapGajiBulanan::updateOrCreate(
                [
                    'id_pegawai' => $pegawai->id_pegawai,
                    'bulan' => $periode,
                ],
                [
                    'jumlah_tanpa_keterangan' => $alfa,
                    'hadir' => $hadir,
                    'izin' => $izin,
                    'sakit' => $sakit,
                    'alfa' => $alfa,
                    'total_potongan' => $total_potongan,
                    'gaji_bersih' => $gaji_bersih,
                    'updated_at' => Carbon::now(),
                ]
            );
        }

        return response()->json([
            'status' => 'success',
            'message' => "Rekap gaji bulan $periode berhasil dibuat",
        ]);
    }

    /**
     * =========================
     * LOCK GAJI
     * =========================
     */
    public function lock(Request $request)
    {
        $bulan = $request->bulan;
        $tahun = $request->tahun;
        $periode = $tahun.'-'.$bulan;

        DB::table('rekap_gaji_bulanan')
            ->where('bulan', $periode)
            ->update([
                'updated_at' => now(),
            ]);

        return back()->with('success', 'Gaji bulan ini berhasil dikunci');
    }

    /**
     * =========================
     * DETAIL GAJI PEGAWAI
     * =========================
     */
    public function detail(Request $request, $id_pegawai)
    {
        $bulan = $request->input('bulan', date('m'));
        $tahun = $request->input('tahun', date('Y'));
        $periode = $tahun.'-'.$bulan;

        $pegawai = Pegawai::findOrFail($id_pegawai);

        // Ambil rekap gaji bulan ini
        $rekap = RekapGajiBulanan::where('id_pegawai', $id_pegawai)
            ->whereYear('created_at', $tahun)
            ->whereMonth('created_at', $bulan)
            ->first();

        // Ambil absensi pegawai bulan ini
        $absensi = Absensi::where('id_pegawai', $id_pegawai)
            ->whereYear('tanggal', $tahun)
            ->whereMonth('tanggal', $bulan)
            ->orderBy('tanggal', 'asc')
            ->get();

        return view('gaji.detail', compact('pegawai', 'rekap', 'absensi', 'bulan', 'tahun'));
    }
}
